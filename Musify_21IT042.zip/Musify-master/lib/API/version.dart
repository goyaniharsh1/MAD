const appVersion = '2024.3.31';
