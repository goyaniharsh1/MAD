import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get about => 'About';

  @override
  String get accentChangeMsg => 'Accent color has been changed';

  @override
  String get accentColor => 'Accent color';

  @override
  String get add => 'Add';

  @override
  String get addToPlaylist => 'Add to playlist';

  @override
  String get addedSuccess => 'Added successfully';

  @override
  String get album => 'Album';

  @override
  String get appUpdateIsAvailable => 'App update is available';

  @override
  String get audioQuality => 'Audio quality';

  @override
  String get audioQualityMsg => 'Audio quality has been changed';

  @override
  String get backedupSuccess => 'Backed up successfully';

  @override
  String get backupError => 'Error while data backup';

  @override
  String get backupUserData => 'Backup user data';

  @override
  String get becomeSponsor => 'Become a sponsor';

  @override
  String get cacheMsg => 'Cache cleared successfully';

  @override
  String get cancel => 'Cancel';

  @override
  String get chooseBackupDir => 'Choose backup directory';

  @override
  String get chooseRestoreDir => 'Choose restore directory';

  @override
  String get clear => 'Clear';

  @override
  String get clearCache => 'Clear cache';

  @override
  String get clearRecentlyPlayed => 'Clear recently played history';

  @override
  String get clearRecentlyPlayedQuestion => 'Clear recently played history?';

  @override
  String get clearSearchHistory => 'Clear search history';

  @override
  String get clearSearchHistoryQuestion => 'Clear search history?';

  @override
  String get confirm => 'Confirm';

  @override
  String get confirmation => 'Confirmation';

  @override
  String get copyLogs => 'Copy logs';

  @override
  String get copyLogsNoLogs => 'No logs found to copy';

  @override
  String get copyLogsSuccess => 'Logs copied successfully. ';

  @override
  String get customPlaylistAddInstruction => 'If you add YouTube playlist, fill only YouTube playlist ID field, if you create your own playlist leave YouTube playlist ID empty and fill only: Name, Image link (optional), Description (optional)';

  @override
  String get customPlaylistDesc => 'Custom playlist description';

  @override
  String get customPlaylistImgUrl => 'Custom playlist image link';

  @override
  String get customPlaylistName => 'Custom playlist name';

  @override
  String get download => 'Download';

  @override
  String get downloadAppUpdate => 'Download app update';

  @override
  String get dynamicColor => 'Dynamic accent color (Android 12+)';

  @override
  String get error => 'Something went wrong';

  @override
  String get folderRestrictions => 'Due to new restrictions on Android, it is essential to select specific and appropriate folders for different file types. Please ensure that you choose either the \'Documents\' or \'Downloads\' folder for the app backup.';

  @override
  String get home => 'Home';

  @override
  String get language => 'Language';

  @override
  String get languageMsg => 'Language has been changed';

  @override
  String get licenses => 'Licenses';

  @override
  String get lyrics => 'Lyrics';

  @override
  String get lyricsNotAvailable => 'No lyrics available';

  @override
  String get more => 'More';

  @override
  String get noLikedPlaylists => 'You haven\'t liked any playlists yet';

  @override
  String get notYTlist => 'This is not a YouTube playlist ID';

  @override
  String get nowPlaying => 'Now playing';

  @override
  String get others => 'Others';

  @override
  String get pages => 'Pages';

  @override
  String get playlist => 'Playlist';

  @override
  String get playlistUpdated => 'Playlist updated successfully';

  @override
  String get playlists => 'Playlists';

  @override
  String get provideIdOrNameError => 'Please provide YouTube ID or custom playlist name';

  @override
  String get recentlyPlayed => 'Recently played';

  @override
  String get recentlyPlayedMsg => 'Recently played history cleared';

  @override
  String get recommendedForYou => 'Recommended for you';

  @override
  String get remove => 'Remove';

  @override
  String get removePlaylistQuestion => 'Remove this playlist?';

  @override
  String get removeSearchQueryQuestion => 'Remove this search query?';

  @override
  String get restoreError => 'Error while data restore';

  @override
  String get restoreUserData => 'Restore user data';

  @override
  String get restoredSuccess => 'Restored successfully';

  @override
  String get search => 'Search';

  @override
  String get searchHistoryMsg => 'Search history cleared';

  @override
  String get settingChangedMsg => 'Setting changed';

  @override
  String get settings => 'Settings';

  @override
  String get songAdded => 'Song added successfully!';

  @override
  String get songRemoved => 'Song removed successfully!';

  @override
  String get songs => 'songs';

  @override
  String get sponsorProject => 'Sponsor the project';

  @override
  String get suggestedArtists => 'Suggested artists';

  @override
  String get suggestedPlaylists => 'Suggested playlists';

  @override
  String get themeMode => 'Theme mode';

  @override
  String get tools => 'Tools';

  @override
  String get understand => 'I understand';

  @override
  String get undo => 'undo';

  @override
  String get userLikedPlaylists => 'User liked playlists';

  @override
  String get userLikedSongs => 'User liked songs';

  @override
  String get userOfflineSongs => 'User offline songs';

  @override
  String get userPlaylists => 'User playlists';

  @override
  String get youtubePlaylistID => 'YouTube playlist ID';
}
